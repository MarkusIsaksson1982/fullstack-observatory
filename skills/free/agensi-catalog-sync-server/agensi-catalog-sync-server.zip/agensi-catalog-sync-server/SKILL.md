---
name: "agensi-catalog-sync-server"
description: "A shared, multi-agent MCP server that synchronizes local Agensi skill libraries with the live marketplace. Provides tools for scanning, version comparison, drift detection, footprint tracking, and publishing preparation across Grok, Gemini, and Codex."
version: 1.0.0
author: Markus Isaksson
license: MIT
price: 0
tags: ["grok", "gemini", "codex", "agensi", "mcp", "sync", "library-audit", "publishing", "meta", "free"]
---

# Agensi Catalog Sync Server

**Why This Skill Exists**  
As creators maintain skills across multiple AI coding agents (Grok, Gemini, Codex, and others), keeping local libraries in sync with the live Agensi marketplace becomes increasingly difficult. Version drift, unpublished work, and the 50-entry live cap are hard to manage when each agent only sees its own slice of the catalog. This skill provides the shared infrastructure layer that gives all supported agents a consistent view of local vs. live state.

## What You'll Gain

- A single, reusable MCP server that can scan multiple agent skill roots
- Read-only discovery tools for local roots, marketplace footprint, and publish intent validation
- Automated detection of version drift, unpublished skills, and ready-to-publish items
- Footprint awareness against the 50-entry live cap
- Owned-root helpers to prepare skills for publishing and record published versions
- A foundation that higher-tier skills can build upon

## When to Use This Skill

Use this skill when:
- You want a reliable way to keep your local skill library in sync with what is actually live on Agensi
- You maintain skills across multiple agents (Grok + Gemini + Codex) and need a shared source of truth
- You need to run regular hygiene checks before a publishing push
- You want to enforce the 50 live-listing cap across your entire portfolio

**When You DON'T Need This Skill**
- You only work with a single agent and a very small number of skills
- You are actively authoring or iterating on individual skills
- You only need one-time manual checks

## Agent Operating Procedure

### Phase 1: Configuration & Discovery
Load the multi-root configuration (`agensi-sync.config.json`) and discover all configured local skill roots.

### Phase 2: Local Scan
Call `scan_local_roots` to scan configured roots and extract normalized metadata from `SKILL.md`, catalog files, and status-tier folders.

### Phase 3: Live Marketplace Fetch
Use the configured Agensi MCP connection and shared marketplace cache to retrieve the current published state for the creator.

### Phase 4: Comparison & Analysis
Compare local state against live data to identify:
- Unpublished Grok/Gemini/Codex-authored skills
- Version drift
- Skills ready for update
- Footprint pressure against the 50-entry cap

### Phase 5: Recommendations & Actions
Use `aggregate_footprint`, `validate_publish_intent`, and `suggest_publishing_actions` before staging any change. Use write helpers only when the caller owns the target root and the user has approved the action.

## Expected Output

A structured report (markdown + optional JSON) containing:
- Summary counts (local vs live, unpublished, drift, cap status)
- Categorized lists of skills needing attention
- Specific recommended actions (publish, update version, deprecate, etc.)
- Optional machine-readable export in the `live-local-status` schema format

## Quick Start Prompt

```
Set up the Agensi Catalog Sync Server so I can see which of my skills are out of sync with the live marketplace across my Grok, Gemini, and Codex libraries.
```

## Works Well With

**Free meta layer (foundational group):**
- **Agensi Skill Authoring** (free)
- **Iterating Agensi Skills** (free)
- **Agensi Free Skill Explorer with Grok** (free)
- **Agensi Skill Publishing Assistant with Grok** (free)

**Higher-tier Grok-optimized tools (recommended companions):**
- **Agensi Skill Library Auditor with Grok** ($5) - Deeper Grok-specific audit on top of this shared server
- **Agensi Skill Scout & Evaluator with Grok** ($8) - Strategic portfolio analysis using the shared sync data
- **Skill Evaluation & Iteration with Grok** ($5)
- **Skill Catalog Strategy & Optimization with Grok** ($10)

## Compatibility

This skill is designed as a neutral, multi-agent foundation. It has been developed with **Grok in Grok Build**, **Gemini 3.1 in Gemini CLI**, and **GPT-5.5 in the Codex CLI** on **Windows 11**. It may need adaptations to setup in various environments and CLI configurations.

The bundled MCP server (`mcp-server/agensi_catalog_mcp_server.py`) is the canonical implementation maintained in `dev/agensi-shared/mcp/catalog-server/`. It can be used by any MCP-compatible agent when properly configured with the appropriate model root(s).

## Permissions

**Permission Profile**: Analysis + Limited Write + Network (MCP Server)

**Tools Used**
- **Terminal / Shell**: Sometimes - To run the MCP server process
- **Read Files**: Yes - Scans local skill directories across configured roots
- **Write Files**: Sometimes - Generates reports and can prepare skills for publishing with user approval
- **Browser / Network Access**: Yes - Connects to the Agensi MCP server

**Environment Variables**
- `AGENSI_API_KEY` (required)
- `AGENSI_SYNC_CONFIG` (path to multi-root config)

**File Scopes**
- All configured skill roots via `agensi-sync.config.json`
- `mcp-server/` inside this skill package
- Shared data and reports directories configured under `shared_paths`

**Notes**
This skill ships its own MCP server. After installation, configure your agent to run the server. See `README.md` and `mcp-server/agensi-sync.config.example.json`.
