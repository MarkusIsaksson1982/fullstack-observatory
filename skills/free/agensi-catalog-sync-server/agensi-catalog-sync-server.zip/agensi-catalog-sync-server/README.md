# Agensi Catalog Sync Server

A neutral, multi-agent MCP server for synchronizing local Agensi skill libraries with the live marketplace state.

This skill ships its own MCP server implementation so that it can be used in a self-contained way with Grok Build, Gemini CLI, Codex CLI, and other compatible agents.

## Installation

After installing this skill through Agensi, copy or symlink the `mcp-server/` folder to a location of your choice and configure your agent's MCP settings to launch it.

Runtime requirement: Python 3.10+.

## Quick Setup (Grok Build)

1. Copy the `mcp-server/` directory to a stable location, such as `~/.grok/mcp-servers/agensi-catalog-sync-server`.
2. Create a `.env` file from `.env.example` and add your `AGENSI_API_KEY`.
3. Create an `agensi-sync.config.json` from `mcp-server/agensi-sync.config.example.json`.
4. Add the following to your MCP configuration, usually `~/.grok/mcp.json` or equivalent:

```json
{
  "mcpServers": {
    "agensi-catalog": {
      "command": "python",
      "args": [
        "<path-to-mcp-server>/agensi_catalog_mcp_server.py"
      ],
      "env": {
        "AGENSI_SYNC_CONFIG": "<path-to-config>/agensi-sync.config.json"
      }
    }
  }
}
```

5. Restart Grok Build.

## Configuration

The server is driven by `agensi-sync.config.json`. See `mcp-server/agensi-sync.config.example.json` for the expected format.

Define one root per agent family and declare the local layout used by that root:

```json
{
  "creator_slug": "your-agensi-creator-slug",
  "policy": {
    "live_listing_cap": 50,
    "default_drift_policy": "batch-with-version",
    "require_version_for_publish_or_update": true
  },
  "roots": {
    "codex": {
      "local_root": "C:/Users/you/dev/codex/agensi",
      "catalog": "catalog.yaml",
      "layout": "catalog-yaml",
      "status_export": "reports/live-local-status.json"
    },
    "gemini": {
      "local_root": "C:/Users/you/dev/gemini/agensi",
      "catalog": "catalog.yaml",
      "layout": "catalog-yaml"
    },
    "grok": {
      "local_root": "C:/Users/you/dev/grok/agensi/skills",
      "layout": "status-tier-folders"
    }
  },
  "shared_paths": {
    "cache_dir": "C:/Users/you/dev/agensi-shared/data",
    "live_local_dir": "C:/Users/you/dev/agensi-shared/data/live-local",
    "reports_dir": "C:/Users/you/dev/agensi-shared/reports",
    "live_local_schema": "C:/Users/you/dev/agensi-shared/schemas/live-local-status.schema.json"
  }
}
```

Core tools exposed by the server:

- `scan_local_roots`: read-only normalized scan across configured roots
- `aggregate_footprint`: live/local footprint summary, including 50-entry cap pressure
- `validate_publish_intent`: preflight gate for publish/update actions
- `sync_publishing_status`: local report generation from live marketplace data
- `suggest_publishing_actions`: prioritized publishing and update recommendations
- `prepare_skills_for_publishing`: owned-root staging helper
- `record_published_version`: owned-root version bookkeeping helper

## Gemini Section

### Setup & Launch (Gemini CLI)

1. **Local Deployment**: Copy the `mcp-server/` directory to a persistent location on your machine.
2. **Environment**: Create a `.env` file in that directory with your `AGENSI_API_KEY`.
3. **Configuration**: Add the server to your Gemini CLI configuration, typically via an `mcp_servers` block in your settings or a local policy file:

```yaml
mcp_servers:
  agensi-catalog:
    command: "python"
    args:
      - "C:/path/to/mcp-server/agensi_catalog_mcp_server.py"
    env:
      AGENSI_SYNC_CONFIG: "C:/path/to/agensi-shared/agensi-sync.config.json"
```

4. **Verification**: Run `gemini mcp list` or equivalent to ensure the server is recognized.

**Gemini-Specific Notes:**
- **Context Efficiency**: Gemini CLI is optimized for surgical file reads. Use `scan_local_roots` to get a high-level overview, then drill down into specific skill directories only when necessary.
- **Sub-Agent Delegation**: Specialized sub-agents can perform deeper analysis on drift issues identified by this server.

## Codex Section

### Setup & Launch (Codex / OpenAI)

1. **Deployment**: Deploy the `mcp-server/` directory to your local development environment.
2. **Security**: Ensure `.env` is populated with `AGENSI_API_KEY`.
3. **Integration**: Update your Codex MCP connector configuration, such as `mcp_config.json`:

```json
{
  "mcpServers": {
    "agensi-catalog": {
      "command": "python",
      "args": ["C:/path/to/mcp-server/agensi_catalog_mcp_server.py"],
      "env": {
        "AGENSI_SYNC_CONFIG": "C:/path/to/agensi-shared/agensi-sync.config.json"
      }
    }
  }
}
```

**Codex-Specific Notes:**
- **Drift Logic**: Codex relies on `catalog.yaml` for status tracking. Ensure the root is configured with `layout: "catalog-yaml"` in the shared config to enable accurate syncing.
- **Validation-First**: Use `validate_publish_intent` when preparing publish/update actions so version transitions and cap pressure are checked before staging.

## Suggested Workflow if You're Intending to Use This with Another Model

1. **Central Server** - Run one instance of the Agensi Catalog Sync Server pointed at the shared `agensi-sync.config.json`.
2. **Per-Model Roots** - Each agent (Grok, Gemini, Codex) maintains its own skill root but registers it in the shared config.
3. **Shared Cache** - All agents read from and optionally write to a common `data/` directory under `agensi-shared/`.
4. **Read-First by Default** - Use `scan_local_roots`, `aggregate_footprint`, and `validate_publish_intent` before making file changes.
5. **Owned Writes Only** - Only allow write operations such as `prepare_skills_for_publishing` or `record_published_version` when the calling model owns the target root.
6. **Drift Resolution** - Each model is responsible for resolving its own drift, but can use `suggest_publishing_actions` for guidance.
7. **Publishing Gate** - Before moving anything to `ready-to-list` or `listed`, call `validate_publish_intent` to respect the 50-entry cap across all roots.

Model-specific workflow files live under `agents/`.

## Common Issues

- **`AGENSI_API_KEY not found`**: Create `mcp-server/.env` from `.env.example`, or pass `AGENSI_API_KEY` through the MCP server environment.
- **Relative paths resolve unexpectedly**: Paths in `agensi-sync.config.json` are resolved relative to that config file. Use absolute paths when sharing a config across machines.
- **No live marketplace count**: Run a live marketplace sync first so `shared_paths.cache_dir/marketplace-cache.json` exists, or provide an accepted manual snapshot in the shared workspace.
- **A configured root reports zero skills**: Confirm the root path and layout. Use `layout: "catalog-yaml"` for roots with `catalog.yaml`; use `layout: "status-tier-folders"` for Grok-style `listed/`, `ready-to-list/`, and `working-state/` folders.
- **Publish validation blocks**: `validate_publish_intent` blocks when the skill is missing locally, the action is unsupported, required version data is absent, or live + ready-to-list count would exceed the configured cap.

## Status

This is a pre-launch skill package located in `dev/agensi-shared/wip-skills/`.

It is intended to become the free, neutral foundation for multi-agent Agensi library synchronization.
