# Christianity Persona Skill Architect with Grok — Draft

**Status**: Early internal draft (working-state). Not yet published or widely tested in real ministry contexts.

This skill is the seed for a new family of **"person-use"** skills on Agensi focused on Christianity, theology, ministry, and faithful living.

## Directory Structure

```
christian-persona-skill-architect-with-grok/
├── SKILL.md
├── personas/
│   ├── BiblicalExegete.md
│   ├── PastoralCompanion.md          (highest safety requirements)
│   ├── ChristianApologist.md
│   ├── LiturgistAndWorshipPlanner.md
│   └── [more to be added]
├── references/
│   ├── person-use-pattern-for-faith-domains.md
│   ├── safety-and-referral.md
│   └── scripture-and-tradition.md
├── examples/
│   └── [delegation examples and sample generated skills]
├── agents/                           (for future Agensi packaging)
│   └── grok.yaml
└── README.md
```

## Current Focus

1. Establish the "person-use" category concept and tagging convention.
2. Provide 4–6 high-quality, safety-aware foundational personas.
3. Define the authoring process and safety standards for this sensitive domain.
4. Create real usage in the author's own ministry-adjacent projects before considering publication.

## Safety First

The `PastoralCompanion` persona and the safety references are the most important artifacts here. Everything else is secondary to getting the boundaries and referral protocols right.

## Next Steps (for the author / users of this draft)

- Exercise the personas in actual sermon prep, study, and ministry planning.
- Iterate the safety language based on real edge cases.
- Add more personas as needed (e.g., Catechist, Spiritual Director for Ministers, Historian of Doctrine).
- When mature, extract one or more publishable Agensi skills (free foundational + possibly paid specialized ones).
- Use the tags `person-use`, `christianity`, `theology`, `ministry` to help establish the new category.

## Relationship to Other Skills in the Ecosystem

This architect is intended to sit alongside:
- Agensi Skill Authoring
- PromptMaster with Grok
- Concept Explainer with Grok
- Task Finisher with Grok
- Skill Evaluation & Iteration with Grok

It is the domain-specific counterpart to the more generic health-gated autonomous operator and other sub-agent pattern skills.

## License & Intent

MIT. Intended as a gift to the Church and to serious Christian technologists and ministers who want to use AI tools responsibly.

---

**Soli Deo Gloria**
