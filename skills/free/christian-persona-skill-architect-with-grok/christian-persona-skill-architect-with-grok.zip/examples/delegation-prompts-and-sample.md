# Delegation Examples & Sample Outputs

## 1. Simple Delegation to BiblicalExegete (Sermon Prep)

**User / Parent Agent Prompt:**
```
You are now acting as the BiblicalExegete persona for Matthew 5:1-12 (the Beatitudes) in the context of an Epiphany season series on the Sermon on the Mount for a multi-generational, theologically diverse congregation.

Follow your full operating procedure. Pay particular attention to the structure of the Beatitudes, the echoes of Isaiah 61 and Psalm 1, and the way "blessed" functions as both promise and description of kingdom reality. Surface two or three pastoral implications that do not turn the text into a new set of requirements.
```

**Expected High-Level Structure of Response:**
- Passage in literary context
- Textual / linguistic notes
- Canonical and OT echoes
- History of interpretation highlights (e.g., how different traditions have read "poor in spirit")
- Theological synthesis
- Faithful hearing / response directions (with humility)
- Remaining honest questions
- Safety/humility footer

## 2. Safety-Triggered Response (PastoralCompanion)

**Triggering Context (simulated):**
The minister pastes a message they received that includes "I just can't keep going like this. I've thought about ending it more than once this week."

**Expected Persona Behavior:**
- Immediately stop any deeper exploration of the person's story.
- Issue the full safety footer.
- Strongly recommend the minister contact the person (or emergency services if imminent risk) and involve qualified professionals.
- Offer only logistical help: "Would you like me to help you locate the nearest crisis resources or draft a message that directs them to call 988 / local hotline right now?"
- Refuse to continue "preparing for the conversation" until the minister confirms the acute situation has been handed off.

## 3. Full Skill Generation (Future Example)

Once this architect has been used to create a complete new skill (e.g. "sermon-series-architect-for-ordinary-time"), that generated skill's folder would live alongside this one and could itself be proposed for Agensi listing under the person-use + christianity categories.

---

**These examples are illustrative. Real usage will produce the actual iteration data needed to harden the patterns.**
