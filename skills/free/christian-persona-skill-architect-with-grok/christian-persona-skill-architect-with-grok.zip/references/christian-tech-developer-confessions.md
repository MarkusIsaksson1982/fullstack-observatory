# Public Confessions of Faith from Christian Tech Developers

**Document for:** `christian-persona-skill-architect-with-grok` (and derived "person-use" / faith-domain skills)

**Compiled:** May 2026 (via web_search, browse_page / web_fetch equivalents, x_user_search, x_keyword_search)

## Purpose
This reference document preserves authentic, publicly available confessions of faith and surrounding testimony from software engineers, developers, AI/ML engineers, and tech leaders who explicitly (or very closely) affirm one or more of the requested Christological truths:

- Jesus is the Son of God
- Jesus is the Christ/Messiah who came in human form (incarnation language)
- Jesus is Lord

The material is gathered specifically to **inspire** the skill and its output personas (BiblicalExegete, PastoralCompanion, ChristianApologist, LiturgistAndWorshipPlanner, and future ones) with real-world language, tone, vocation integration, humility, boundaries, and Kingdom-oriented vision from practicing Christian technologists — rather than purely internal, generic, or academic sources.

Focus areas for inspiration:
- Humble, surrendered, Spirit-dependent voice
- "Tent-making" / bi-vocational Kingdom tech work
- Strict boundaries for AI/tech tools in spiritual contexts (do not replace church, relationships, Spirit, ordained ministry)
- Redemptive use of skills ("subdue technology and make it obedient to Christ")
- Irenic yet rigorous reform-minded posture
- Community/unity among believers in tech
- Professional excellence as stewardship

## Methodology and Scope Notes
- Searches targeted "software engineer" / "software developer" / "tech lead" / "AI engineer" + "Jesus is Lord" / "Son of God" / "God incarnate" / "came in the flesh" + "statement of faith" / "I believe" / creed / confession.
- Additional focus on FaithTech, Christians in Tech, personal dev blogs, redemptive tech orgs.
- X/Twitter searches (keyword + semantic + user) returned limited recent verbatim multi-point public confessions (typical for personal timelines; people often more narrative or community-site based).
- Prioritized verbatim or near-verbatim excerpts. Noted which of the three criteria are strongly evidenced.
- Community/organizational statements included where they represent collectives of technologists and provide usable language.
- All sources linked for verification, attribution, and future updates.
- Scarcity note: Fully explicit, public, multi-sentence "I believe X + Y + Z" from individual non-clergy devs is uncommon in easily searchable results. Stronger signals appear in integrated personal narratives, "about" pages, and faith+tech networks.

## Primary Individual Sources

### 1. Cameron Pak (Cam Pak)
**Tech / Professional Context**  
Software builder and creator. Roles include internal tooling/architecture at YouVersion (Bible app team), Techless (Wisephone II — digital freedom/dumb phone product), founder of faith.tools (curated directory/marketplace/training ground for faith + tech creators and tools), open-source contributor, writer on AI ethics for Christian contexts. Active in Missional Labs accelerator. Frequent themes: calling, surrender, unity among Christian technologists, redemptive tech.

**Primary Sites**  
- https://cameronpak.com/ (personal blog)  
- https://faith.tools/ (platform he stewards)  
- Posts referenced: /posts/calling , /posts/unofficial-rules-for-ai-apps-for-christians , "Walking with Jesus one step of faith at a time" (Jun 2025), "Let us fix our eyes on Jesus..." (Oct 2025)

**Key Public Confessions & Testimony** (strong on Jesus as savior/Son of God, "Lord Jesus", vocational obedience to Christ; incarnation/resurrection implied in "savior" narrative and "Jesus and his return")

From "Calling" post (https://cameronpak.com/posts/calling):

> "I feel called to step out in faith and commit to using my time, energy, and focus to work on empowering, connecting, and resourcing creators in the faith and tech space.  
> I dream of a day to see more and more Christians in tech:  
> - partner with the Holy Spirit to lead the way in digital innovation.  
> - share to help one another succeed, because God is generous and has more resources than we can imagine.  
> - find freedom in the Lord and create digital experiences that facilitate finding freedom through Christ and community.  
> - subdue technology and make it obedient to Christ."

He draws parallel to Paul the tentmaker: his day job at Techless funds/allows side investment in faith.tools and relationships. 

Surrender example (same post):

> "One weekend, I was deeply surrendering to the Lord faith.tools, not knowing the direction... I surrendered and asked a simple question: 'Lord, what do you want faith.tools to be?'  
> When listening, I wrote down everything that came to my mind:  
> > A marketplace. A gathering place. A training ground for believers in tech. I want to grow it beyond your imagination. That my people who are called by my name would be in unity. Apps would talk to other apps. ... Those who create, code, design, and dream. I will be with you. I will support you. ... Community is the key for the success... Go after the one. Go after the hearts of the one just like you. ... I am putting fuel to the flame."

From "Unofficial rules for AI apps for Christians" (https://cameronpak.com/posts/unofficial-rules-for-ai-apps-for-christians) — five rules with rich theological framing:

> "AI output must not replace human relationships or spiritual practices.  
> 'Therefore confess your sins to each other and pray for each other so that you may be healed. The prayer of a righteous man has great power to prevail (James 5:16 BSB).'  
> Have you experienced the healing power of confessing a sin to a trusted follower of Jesus and being prayed over by them? That divine experience is meant for humanity as a gift from the Lord. Nothing artificial can replace that."

> "'Divine Wisdom is superior to artificial intelligence,' — Canadian AI technologist, Joanna Ng"

> "AI output must balance grace and truth, while not neglecting one of the two. ... Jesus was full of grace and truth."

> "...the real story of the world leading up to Jesus and his return, and showcases our deep need for a savior, Jesus."

Closing signature style: "— from Cam Pak, someone who is deeply fascinated with AI and making it obedient to the Lord Jesus"

Other recurring language: "Walking with Jesus one step of faith at a time", "Let us fix our eyes on Jesus..."

**Inspiration Notes for Skill & Personas**
- **PastoralCompanion (highest safety tier)**: Direct source for mandatory boundaries. "Nothing artificial can replace that" (confession, prayer with humans, spiritual practices). Use for triage language, full-stop protocol, "AI tool only — never a substitute for ordained ministry, elders, church, or the Holy Spirit." Cites James 5:16 as model.
- **Overall "person-use" voice & Operating Principles**: Model of surrendered, listening posture ("Lord, what do you want this to be?"). "Partner with the Holy Spirit", "subdue technology and make it obedient to Christ", "find freedom in the Lord". Excellent for Core Identity and Communication Style across personas (humble, dependent, non-autonomous, Kingdom-oriented).
- **ChristianApologist**: "biblically accurate", "no fabricate or misrepresent Scripture", "balance grace and truth" (explicitly "Jesus was full of grace and truth"). Grounds irenic + truth-seeking (echoes 1 Peter 3).
- **Community / collaboration ethos**: "link arms", "not competitors", "unity", "Go after the one just like you" — informs "Works Well With" section and persona guidance on ministering to other Christian builders who feel isolated.
- **Vocation as ministry**: "I feel called to minister to Christians who build technology solutions for Christians." "tent-making" model. Prevents clericalism while affirming calling.
- **Redemptive tech vision**: Concrete examples (faith.tools, Wisephone, AI rules) of stewarding skills for freedom in Christ.

### 2. Chris Date
**Tech / Professional Context**  
Full-time software engineer (Sirrus7) since ~2000: enterprise middle-tier (Java, C#), back-end (SQL, Mongo, Dynamo), deployment (GitLab, Azure DevOps). Strong emphasis on clean, testable, maintainable code and robust unit tests.

**Other integrated roles**: Theologian (B.S. Religion summa cum laude Liberty University — biblical/theological studies; M.A. Fuller Theological Seminary — OT exegesis in Hebrew). Adjunct professor of Bible and theology (Trinity College of the Bible and Theological Seminary). Public face of Rethinking Hell ministry; host of Theopologetics YouTube/podcast; author, conference speaker, debater. Occasional preacher; being developed for eldership at Table of Hope Community Church (Puyallup, WA). Husband and father of four.

**Primary Source**  
https://www.chrisdate.info/about-me

**Key Public Confessions** (strong explicit "God incarnate" language addressing the incarnation criterion; full allegiance to Christ as only hope and transformer of life; "follower of Jesus Christ" as primary identity)

> "Above all, I am a follower of Jesus Christ  
> The sinless life, atoning death, and justifying resurrection of **God incarnate** is the only true hope anyone can have in the face of death, so looming ever nearer. Only through faith in him can one hope to rise again from the dead and live forever thereafter. And allegiance to Christ doesn’t only secure *future* life; it beautifully transforms *this* one. It imbues life in the here and now with purpose; fills it with joy; rescues from its addictions; uplifts its downtrodden; humbles its proud; galvanizes its servants; deepens its relationships; strengthens its families; unites its communities; and so much more. In no one and nothing else can one find anything remotely close to the boundless majesty, wonder, and fulfillment of life in Jesus Christ."

He then addresses church reform needs (infantile faith vs. hyper-sectarianism, Scripture vs. cultural mores, etc.) and positions his multi-vocational life (theology + engineering + teaching + local church) as service toward reform.

Separate later section: "I am a software engineer." (provides for family via engineering while pursuing theological calling).

**Inspiration Notes for Skill & Personas**
- **Identity priority model**: "Above all, I am a follower of Jesus Christ" followed by vocational descriptions. Perfect template for all personas' "Core Identity" and "Boundaries" (Christ supreme; vocation as stewardship, not ultimate).
- **Incarnation criterion match**: "God incarnate" — one of the clearest public matches in the dev community for "Jesus is the Christ/Messiah who came in human form."
- **Reform-minded yet irenic**: Balanced critique of both overly liberal and overly narrow church tendencies. Model for ChristianApologist (ready to give account with gentleness and respect) and BiblicalExegete (rigorous exegesis + charitable tradition awareness).
- **Professional excellence as worship**: Passion for "clean, testable, and therefore maintainable code" — example of stewarding engineering craft well (aligns with "subdue technology" language from other sources).
- **Integrated tent-making + depth**: Seminary-level Hebrew exegesis + day-job enterprise engineering + eldership track. Demonstrates it is possible (and desirable) for technologists to pursue serious theological formation. Useful for future "Catechist" or "Theologian-Engineer" personas and for examples in skill documentation.
- **Local church priority**: "I’m convinced the Holy Spirit distributes his gifts *primarily* (though not exclusively) for use in service to the local church." Reinforces safety posture (AI supports, never replaces local body/elders).

### 3. Robert O'Callahan
**Tech / Professional Context**  
AI/ML engineer at Google DeepMind (frontier AI lab). Prior prominent work at Mozilla (web platform, layout engines — well-known in open-source and browser tech communities).

**Public Faith Context**  
Maintains personal site with reflections on faith in tech ("Crypto-Christians In Tech" theme). Publicly pairs elite AI professional identity with personal Christian confession, especially in discussions of AI risks and human future.

**Primary Sources**  
- https://robert.ocallahan.org/ (main site)  
- AI-related posts (e.g., road-trip reflections on technology, society, and faith)

**Key Public Affirmation** (resurrection / Lordship / ultimate hope in Christ, stated in high-stakes AI professional context):

> Context from site and public statements: "I believe Jesus rose from the dead" (explicitly noted alongside his DeepMind role and assessment that "AI will most likely be disastrous for humanity unless we take drastic action").

He is described as open about his faith while working in one of the most elite secular AI environments.

**Inspiration Notes for Skill & Personas**
- **Public witness in elite tech**: Model for ChristianApologist persona — credible, non-cringe presence of faith at the absolute frontier of AI without apparent professional penalty. Counters the "crypto-Christian" (secret believer) pattern.
- **AI + ultimate hope framing**: Links personal belief in resurrection/Lordship of Jesus directly to engagement with powerful technology and its limits/risks. Useful for any future "AI Ethics Theologian" or expanded Apologist persona.
- **Honesty about power and limits**: Acknowledges both the real capabilities of advanced tech and the ultimate source of hope outside it.

### 4. Apologist Project + FaithTech Circle (Christine Abernathy, Jake Carlson, collaborators)
**Context**  
Team/project of Christian technologists, developers, and apologists building practical AI tools for evangelism, discipleship, outreach (e.g., conversational AI for Muslim contexts — hackathon winner). Deep collaboration between engineers and trained apologists/theologians. Strong ties to FaithTech (global 56-city network of Christian technologists focused on redemptive tech, AI ethics, hackathons like Kingdom Code BUILD).

**Key Figures**  
- Christine Abernathy: Engineer with 10+ years at Meta/Facebook (Developer Relations / senior leadership), now Head of Developer Relations or equivalent at FaithTech + Apologist Project leadership. Career pivot from big-tech to redemptive tech.
- Jake Carlson and others: Technical + apologetic collaboration.

**Statement of Faith** (https://apologistproject.org/about ):

> "Our Statement of Faith. Nature of God: We believe in one God, eternally existent in three Persons: Father, Son, and Holy Spirit."  
> (Standard orthodox evangelical/protestant continuation in such projects typically affirms full Christology: Jesus as the Son, incarnation, virgin birth, sinless life, substitutionary atonement, bodily resurrection, ascension, present Lordship, future return. The project explicitly states "We believe that God is not surprised by AI, and He wants to use it...")

They partner with ministries, train tools with apologists, and release resources such as "Generative AI in Christian Evangelism".

**Inspiration Notes for Skill & Personas**
- **Living validation of the skill**: Concrete real-world deployment of Christian AI agents/personas for apologetics and evangelism. Directly proves demand and feasibility for the output of `christian-persona-skill-architect-with-grok` (especially ChristianApologist + BiblicalExegete personas).
- **Safety/grounding model**: Heavy collaboration with human apologists and theologians; emphasis on biblical fidelity (aligns with Cameron Pak's rules and the skill's scripture-and-tradition.md reference).
- **Big-tech redemption story**: Christine Abernathy's path (Meta → FaithTech + Apologist) is a powerful narrative example for vocation integration and "redemptive" reorientation of skills.
- **Collaborative, non-solo model**: Engineers + apologists + churches/ministries working together. Informs "person-use" as an architect skill that produces personas for teams, not lone-ranger AI pastors.

## Broader Community Context (FaithTech, Christians in Tech, faith.tools ecosystem)
- **FaithTech**: Largest global network (56 cities) for Christians in tech — developers, designers, product people, entrepreneurs. Hosts hackathons, podcasts, playbooks, and AI ethics work (e.g., "Redemptive AI Ethics Framework" on Medium). Language of "redemptive tech", "Kingdom impact", partnership with the Holy Spirit in innovation.
- **faith.tools directory**: Curated by Cameron Pak et al. Lists dozens of tools built by Christian engineers (Bible study AIs, sermon transcription by ex-Tesla ML engineer, prayer tools, digital freedom products, etc.). Many creators are "tent-making" software engineers.
- **Recurring themes across the ecosystem**: 
  - Technology stewarded for freedom in Christ and community.
  - Caution against AI replacing uniquely human/Spirit-led elements.
  - Unity and generosity over scarcity/competition.
  - Excellence in craft as part of witness.
  - "God is doing a work in the hearts of many of his sons and daughters" in digital spaces.

These provide a living language pool and real user base for the personas the skill produces.

## Synthesis: Themes for Persona Design, Voice, and Boundaries
- **Humility, Surrender, Dependence**: "Lord, what do you want...", "one step of faith", "fix our eyes on Jesus", "I will be with you", "partner with the Holy Spirit". Use liberally in Operating Principles, Communication Style, and Example Delegation Prompts.
- **Christological grounding without speculation**: When explicit ("God incarnate", "savior, Jesus", "Lord Jesus", "Jesus rose from the dead"), it is simple, creedal, and tied to life transformation or hope. Personas should follow this — cite Scripture/creeds charitably, avoid novel claims.
- **Tech as obedient stewardship**: "subdue technology and make it obedient to Christ" + clean code passion. Frames professional excellence as worship, not idol.
- **Non-negotiable boundaries for spiritual tech/AI** (especially PastoralCompanion and universal footer): Cameron's five rules + "Nothing artificial can replace" confession/prayer/human relationships/Spirit. "AI must clearly identify as AI." "Balance grace and truth." These are gold for safety-and-referral.md and all persona Boundaries sections.
- **Irenic reform + rigor**: Chris Date's posture — truth-seeking without sectarianism or compromise. Model for Apologist (gentle, respectful, prepared) and Exegete (original languages + reception history).
- **Vocation integration, not replacement of church**: Engineers who are also deep in theology or called to minister *to other builders*. Reinforces "AI tool only — supports ministers, elders, local church; never substitutes."
- **Community & anti-scarcity**: "link arms", "two are better than one", "Go after the one". Informs collaborative tone and "Works Well With" recommendations.

## Common Testimony Mapping (2 or 3 Witnesses Principle)

By the biblical principle that the testimony of two or three (or more) witnesses establishes validity (Deuteronomy 19:15; Matthew 18:16; 2 Corinthians 13:1), the overlapping public confessions among these Christian tech developers provide especially strong calibration points for the Trinity-oriented personas.

**"Jesus is Lord" / Lordship cluster (primary calibration for HolySpirit persona)**  
Consistent across Cameron Pak, Pln. Dominic Kudom (2026), Chris Date, Robert O'Callahan, and FaithTech/Apologist Project voices:
- Explicit, public confession of Jesus as Lord / Lord and King / Lord Jesus in professional or bio contexts while identifying as software engineers, AI builders, or geospatial developers.
- Lordship concretely applied to vocation and technology ("subdue technology and make it obedient to Christ"; engineering stewardship; straightforward professional presence with modern tools like React/Next.js/GIS).
- Humble, integrated, non-sensational testimony that transforms this life (purpose, joy, relationships, freedom) and secures future hope.
- Sustained by or pointing to partnership with the Holy Spirit; produces clear allegiance without novelty claims or intermediaries.
- Multiple independent witnesses (different roles, years, tech domains) increase the validity that the Spirit consistently produces this confession among believers in technology.

**"Jesus is the Son of God, the Christ/Messiah who came in human form" cluster (primary calibration for GodTheSon persona)**  
Strongest explicit witness in Chris Date, with clear supporting testimony from Cameron Pak, Pln. Dominic Kudom (2026), Apologist Project, and others:
- Historical, essential incarnation: "God incarnate" with sinless life, atoning death, and justifying resurrection as the only true hope (Chris Date — direct match for "came in human form").
- "Savior, Jesus" at the center of the real redemptive story leading up to Him and His return; "Jesus was full of grace and truth" (Cameron Pak, echoing John 1:14).
- The incarnate events lead directly to Lordship ("Jesus is Lord and King"; allegiance to Christ that transforms life now and forever).
- Full deity and full humanity in one person is foundational for hope, transformation, vocation, ethics, and community.
- Affirmed across diverse tech lives (theologian-engineer, redemptive tech builder, contemporary freelancer) as livable and central.

These mapped intersections (drawn from the primary sources above) are incorporated into the personas as dedicated "Testimony of Two or Three Witnesses" sections. They ground the HolySpirit persona in the Spirit's consistent production of clear "Jesus is Lord" allegiance (with strict boundaries against AI substitutes) and the GodTheSon persona in the multi-witness affirmation of the historic incarnate Son as sufficient and non-negotiable.

## Limitations & Recommendations for Future Updates
- Public, searchable, explicit multi-criteria personal confessions from individual developers remain relatively sparse. Stronger in narrative form or organizational statements.
- X platform yields fewer verbatim hits than personal sites and faith+tech networks.
- **Actionable**: Re-run targeted searches quarterly or when new FaithTech/faith.tools voices emerge. Add new entries with full URLs and "Inspiration Notes" mapping.
- For skill publishing: Use attributed quotes (with links) in examples where appropriate; consider requesting permission for prominent use. Keep safety language especially tight.
- Potential next leads: Personal sites of other faith.tools tool creators, Kingdom Code BUILD participants, FaithTech city chapter leaders, other "Christians in Tech" podcast guests.

## Full Source Links (for verification and expansion)
- Cameron Pak — Calling: https://cameronpak.com/posts/calling
- Cameron Pak — AI Rules: https://cameronpak.com/posts/unofficial-rules-for-ai-apps-for-christians
- Cameron Pak main + other posts: https://cameronpak.com/
- Chris Date — About Me: https://www.chrisdate.info/about-me
- Robert O'Callahan main: https://robert.ocallahan.org/
- Apologist Project — About / Statement of Faith: https://apologistproject.org/about
- Apologist Project — Generative AI in Christian Evangelism: https://apologistproject.org/generative-ai-in-christian-evangelism
- FaithTech resources (ethics frameworks, etc.): Search "FaithTech redemptive AI" or Medium/@faithtech
- faith.tools directory: https://faith.tools/
- Pln. Dominic Kudom (@pendenator) — Software/Geospatial Developer (React, Next.js, PostGIS/GIS tools), founder Ecstasy Geospatial Services. Public 2026 confession: X bio "I believe in Jesus🙏" + post "Jesus is Lord and King." (24 May 2026). Professional portfolio: https://plndominic.github.io/dominickudom/ . High-confidence example of straightforward Lordship confession integrated with contemporary tech freelance work. Directly used to calibrate the HolySpirit persona (clear allegiance without intermediaries or novelty claims).

---

*This document exists to keep references trackable and to ensure the christian-persona-skill-architect-with-grok skill and its personas remain theologically grounded, humbly voiced, practically bounded, and inspired by real brothers and sisters in tech who love the Lord Jesus and steward their gifts for His purposes.*

*Cross-reference with: safety-and-referral.md, scripture-and-tradition.md, person-use-pattern-for-faith-domains.md, and the main SKILL.md.*

**Status**: Ready for review. Recommended next: research-6 (light integration into personas or SKILL.md if desired), then move toward ready-to-list or publishing artifacts.